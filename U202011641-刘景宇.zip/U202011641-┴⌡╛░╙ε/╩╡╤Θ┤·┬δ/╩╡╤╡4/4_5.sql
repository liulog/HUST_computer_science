-- 5) 查询任意两个客户的相同理财产品数
--   请用一条SQL语句实现该查询：
SELECT
	c_id1 AS pro_c_id,
	c_id2 AS pro_c_id,
	total_count 
FROM
	(SELECT
		c1.c_id AS c_id1,
		c2.c_id AS c_id2,
		(SELECT count(*) 
		FROM finances_product
		WHERE p_id in	(select distinct pro_pif_id
										from property 
										where pro_type=1 and pro_c_id=c_id1) 
					and p_id in (select distinct pro_pif_id
										from property 
										where pro_type=1 and pro_c_id=c_id2) 
		) AS total_count 
	FROM
		client c1,
		client c2 
	WHERE
	c1.c_id <> c2.c_id ) AS tmp_table
WHERE total_count > 1;
-- SELECT
-- 	c_id1 AS pro_c_id,
-- 	c_id2 AS pro_c_id,
-- 	total_count 
-- FROM
-- 	(SELECT
-- 		c1.c_id AS c_id1,
-- 		c2.c_id AS c_id2,
--         (
-- 		    SELECT count(*) 
-- 		    FROM property 
-- 	    	WHERE
-- 		    	pro_pif_id IN ( SELECT DISTINCT pro_pif_id FROM property WHERE pro_type = 1 AND pro_c_id = c1.c_id ) 
-- 			AND pro_pif_id IN ( SELECT DISTINCT pro_pif_id FROM property WHERE pro_type = 1 AND pro_c_id = c2.c_id ) 
-- 		    GROUP BY
-- 			    pro_pif_id 
-- 	    ) AS total_count 
-- 	FROM
-- 		client c1, client c2 
-- 	WHERE
-- 	c1.c_id < c2.c_id ) AS tmp_table 
-- WHERE total_count is not null and total_count > 3 
-- ORDER BY
-- 	c_id1;


/*  end  of  your code  */