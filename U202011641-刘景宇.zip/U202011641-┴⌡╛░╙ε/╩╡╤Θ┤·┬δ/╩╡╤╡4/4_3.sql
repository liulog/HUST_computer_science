   -- 3) 查询购买了所有畅销理财产品的客户
--   请用一条SQL语句实现该查询：



SELECT c_id as pro_c_id
FROM client
WHERE NOT EXISTS (
	SELECT * 
	FROM (SELECT pro_pif_id FROM property WHERE pro_type=1 GROUP BY pro_pif_id HAVING count(*) > 2) as ptb1
	where not exists(
		select *
		from (select pro_pif_id from property where pro_type=1 and pro_c_id = c_id) as ptbc
		where ptb1.pro_pif_id=ptbc.pro_pif_id
	)
);

/*  end  of  your code  */