  -- 2) 投资积极且偏好理财类产品的客户
--   请用一条SQL语句实现该查询：


select ptb1.pro_c_id 
from
	(select distinct pro_c_id, count(*) as count1 from property where pro_type = 1 group by pro_c_id) as ptb1,
	(select distinct pro_c_id, count(*) as count3 from property where pro_type = 3 group by pro_c_id) as ptb2
where ptb1.pro_c_id = ptb2.pro_c_id and  count1 >= 3 and count1 > count3;



/*  end  of  your code  */