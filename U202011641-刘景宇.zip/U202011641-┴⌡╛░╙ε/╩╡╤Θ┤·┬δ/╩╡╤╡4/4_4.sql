    -- 4) 	查找相似的理财产品

--   请用一条SQL语句实现该查询：

select pro_pif_id, cc, prank
from(
select pro_pif_id, count(*) as cc, dense_rank() over(order by count(*) desc) as prank
from property
where pro_type = 1 and pro_pif_id<>14 and pro_pif_id in (select pro_pif_id
		from property
		where  pro_pif_id<>14 and pro_type=1 and pro_c_id in (
		select pro_c_id
		from (select pro_c_id, dense_rank() over(order by count(*) desc) as rk
				from property
				where pro_type=1 and pro_pif_id=14
				GROUP BY pro_c_id
				order by rk,pro_c_id) as table1
		where rk<=3 ))
group by pro_pif_id
order by cc desc,pro_pif_id
) as tmp_table
where prank <=3;






/*  end  of  your code  */