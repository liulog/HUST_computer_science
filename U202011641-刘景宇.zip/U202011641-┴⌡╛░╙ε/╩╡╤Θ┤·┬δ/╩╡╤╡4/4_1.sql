--  -- 1) 查询销售总额前三的理财产品
-- --   请用一条SQL语句实现该查询：



(select year(pro_purchase_time) as pyear, rank() over(partition by year(pro_purchase_time) order by pro_quantity * p_amount desc) as rk, p_id, pro_quantity * p_amount as sumamount
from finances_product, property
where p_id=pro_pif_id and pro_type=1 and year(pro_purchase_time) = 2010
order by pyear, rk, p_id
limit 3)
union all
(select year(pro_purchase_time) as pyear, rank() over(partition by year(pro_purchase_time) order by pro_quantity * p_amount desc) as rk, p_id, pro_quantity * p_amount as sumamount
from finances_product, property
where p_id=pro_pif_id and pro_type=1 and year(pro_purchase_time) = 2011
order by pyear, rk, p_id
limit 3);

-- /*  end  of  your code  */