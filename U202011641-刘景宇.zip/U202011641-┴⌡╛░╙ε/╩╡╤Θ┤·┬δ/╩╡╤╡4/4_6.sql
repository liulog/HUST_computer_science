 -- 6) 查找相似的理财客户
--   请用一条SQL语句实现该查询：

SELECT c_id as pac, pro_c_id as pbc, common, crank
FROM(SELECT c_id, pro_c_id, count(*) as common, row_number() over(partition by c_id order by count(*) desc, pro_c_id) as crank
FROM client, property
WHERE pro_pif_id in (SELECT pro_pif_id
										FROM property
										WHERE pro_c_id = c_id and pro_type = 1)
			AND pro_type = 1 AND pro_c_id<>c_id
GROUP BY c_id, pro_c_id
ORDER BY c_id, pro_c_id
) as tmp
where crank < 3;


/*  end  of  your code  */