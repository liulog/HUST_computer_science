use finance1;
-- 用insert语句向客户表(client)插入任务要求的3条数据:

insert into client
values (1,"林惠雯","960323053@qq.com","411014196712130323","15609032348","Mop5UPkl");
insert into client
values (2,"吴婉瑜","1613230826@gmail.com","420152196802131323","17605132307","QUTPhxgVNlXtMxN");
insert into client
values (3,"蔡贞仪","252323341@foxmail.com","160347199005222323","17763232321","Bwe3gyhEErJ7");

/* end of you code */