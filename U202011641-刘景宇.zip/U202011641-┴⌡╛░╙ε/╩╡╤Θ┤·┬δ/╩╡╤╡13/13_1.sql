CREATE DATABASE IF NOT EXISTS flight_booking;

USE flight_booking;

-- DESC flight;

set @@foreign_key_checks=OFF;
DROP TABLE IF EXISTS `airline`;
DROP TABLE IF EXISTS `airplane`;
DROP TABLE IF EXISTS `airport`;
DROP TABLE IF EXISTS `flight`;
DROP TABLE IF EXISTS `flightschedule`;
DROP TABLE IF EXISTS `passenger`;
DROP TABLE IF EXISTS `ticket`;
DROP TABLE IF EXISTS `user`;
set @@foreign_key_checks=ON;

CREATE TABLE `airline`  (
  `airline_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `iata` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `airport_id` int NOT NULL,
  PRIMARY KEY (`airline_id`) USING BTREE,
  UNIQUE INDEX `iata`(`iata` ASC) USING BTREE,
  INDEX `airport_id`(`airport_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

CREATE TABLE `airplane`  (
  `airplane_id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `capacity` smallint NOT NULL,
  `identifier` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `airline_id` int NOT NULL,
  PRIMARY KEY (`airplane_id`) USING BTREE,
  INDEX `airline_id`(`airline_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

CREATE TABLE `airport`  (
  `airport_id` int NOT NULL AUTO_INCREMENT,
  `iata` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `icao` char(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `latitude` decimal(11, 8) NULL DEFAULT NULL,
  `longitude` decimal(11, 8) NULL DEFAULT NULL,
  PRIMARY KEY (`airport_id`) USING BTREE,
  UNIQUE INDEX `iata`(`iata` ASC) USING BTREE,
  UNIQUE INDEX `icao`(`icao` ASC) USING BTREE,
  INDEX `name`(`name` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

CREATE TABLE `flight`  (
  `flight_id` int NOT NULL AUTO_INCREMENT,
  `departure` datetime NOT NULL,
  `arrival` datetime NOT NULL,
  `duration` smallint NOT NULL,
  `airline_id` int NOT NULL,
  `airplane_id` int NOT NULL,
  `flight_no` char(8) NOT NULL,
  `from` int NOT NULL,
  `to` int NOT NULL,
  PRIMARY KEY (`flight_id`) USING BTREE,
  INDEX `airline_id`(`airline_id`) USING BTREE,
  INDEX `airplane_id`(`airplane_id`) USING BTREE,
  INDEX `flight_no`(`flight_no`) USING BTREE,
  INDEX `from`(`from`) USING BTREE,
  INDEX `to`(`to`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

CREATE TABLE `flightschedule`  (
  `flight_no` char(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `departure` time NOT NULL,
  `arrival` time NOT NULL,
  `duration` smallint NOT NULL,
  `monday` tinyint NULL DEFAULT 0,
  `tuesday` tinyint NULL DEFAULT 0,
  `wednesday` tinyint NULL DEFAULT 0,
  `thursday` tinyint NULL DEFAULT 0,
  `friday` tinyint NULL DEFAULT 0,
  `saturday` tinyint NULL DEFAULT 0,
  `sunday` tinyint NULL DEFAULT 0,
  `from` int NOT NULL,
  `to` int NOT NULL,
  `airline_id` int NOT NULL,
  PRIMARY KEY (`flight_no`) USING BTREE,
  INDEX `airline_id`(`airline_id`) USING BTREE,
  INDEX `from`(`from`) USING BTREE,
  INDEX `to`(`to`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

CREATE TABLE `passenger`  (
  `passenger_id` int NOT NULL AUTO_INCREMENT,
  `id` char(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `mail` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sex` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `dob` date NULL DEFAULT NULL,
  PRIMARY KEY (`passenger_id`) USING BTREE,
  UNIQUE INDEX `id`(`id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

CREATE TABLE `ticket`  (
  `seat` char(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `ticket_id` int NOT NULL AUTO_INCREMENT,
  `price` decimal(10, 2) NOT NULL,
  `flight_id` int NOT NULL,
  `passenger_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`ticket_id`) USING BTREE,
  INDEX `flight_id`(`flight_id`) USING BTREE,
  INDEX `passenger_id`(`passenger_id`) USING BTREE,
  INDEX `user_id`(`user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

CREATE TABLE `user`  (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lastname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `dob` date NOT NULL,
  `sex` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `admin_tag` tinyint NOT NULL,
  PRIMARY KEY (`user_id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

ALTER TABLE `airline` ADD CONSTRAINT `airport_id4` FOREIGN KEY (`airport_id`) REFERENCES `airport` (`airport_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `airplane` ADD CONSTRAINT `airline_id2` FOREIGN KEY (`airline_id`) REFERENCES `airline` (`airline_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `flight` ADD CONSTRAINT `airline_id1` FOREIGN KEY (`airline_id`) REFERENCES `airline` (`airline_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `flight` ADD CONSTRAINT `airplane_id1` FOREIGN KEY (`airplane_id`) REFERENCES `airplane` (`airplane_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `flight` ADD CONSTRAINT `from1` FOREIGN KEY (`from`) REFERENCES `airport` (`airport_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `flight` ADD CONSTRAINT `to1` FOREIGN KEY (`to`) REFERENCES `airport` (`airport_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `flight` ADD CONSTRAINT `flight_no1` FOREIGN KEY (`flight_no`) REFERENCES `flightschedule` (`flight_no`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `flightschedule` ADD CONSTRAINT `from5` FOREIGN KEY (`from`) REFERENCES `airport` (`airport_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `flightschedule` ADD CONSTRAINT `to5` FOREIGN KEY (`to`) REFERENCES `airport` (`airport_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `flightschedule` ADD CONSTRAINT `airline_id5` FOREIGN KEY (`airline_id`) REFERENCES `airline` (`airline_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `ticket` ADD CONSTRAINT `passenger_id3` FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`passenger_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `ticket` ADD CONSTRAINT `user_id3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE `ticket` ADD CONSTRAINT `flight_id3` FOREIGN KEY (`flight_id`) REFERENCES `flight` (`flight_id`) ON DELETE CASCADE ON UPDATE CASCADE;

