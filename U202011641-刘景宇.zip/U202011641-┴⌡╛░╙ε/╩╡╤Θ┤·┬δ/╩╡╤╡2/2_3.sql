use MyDb;

#请在以下空白处添加适当的SQL语句，实现编程要求

alter table addressBook
    modify QQ char(12),
    rename column weixin to wechat;