USE TestDb1;

#请在以下空白处添加恰当的语句，将表名your_table更改为my_table:

alter table your_table rename to my_table;