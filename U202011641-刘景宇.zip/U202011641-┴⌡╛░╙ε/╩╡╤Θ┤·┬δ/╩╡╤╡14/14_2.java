import java.sql.*;
import java.util.Scanner;

public class Login {
    public static void main(String[] args) {
        Connection connection = null;
        //申明下文中的resultSet, statement

        ResultSet resultSet = null;
        PreparedStatement pstmt = null;
        Scanner input = new Scanner(System.in);

        System.out.print("请输入用户名：");
        String loginName = input.nextLine();
        System.out.print("请输入密码：");
        String loginPass = input.nextLine();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String userName = "root";
            String passWord = "123123";
            String url = "jdbc:mysql://127.0.0.1:3306/finance?useUnicode=true&characterEncoding=UTF8&useSSL=false&serverTimezone=UTC";
            connection = DriverManager.getConnection(url, userName, passWord);
            // 补充实现代码:

            String sql = "select * from client where c_mail = ? ;";
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1,loginName);
            resultSet = pstmt.executeQuery();
            if(resultSet.next()){
                String mail = resultSet.getString("c_password");
                if(mail.equals(loginPass))
                    System.out.print("登录成功。\n");
                else
                    System.out.print("用户名或密码错误！\n");
            }
            else
                System.out.print("用户名或密码错误！\n");
            
         } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
}
