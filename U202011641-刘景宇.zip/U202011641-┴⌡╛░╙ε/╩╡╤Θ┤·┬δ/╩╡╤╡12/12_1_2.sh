# 你写的命令将在linux的命令行运行
# 利用备份文件residents_bak.sql还原数据库:

# mysqladmin -uroot create residnets
mysql -h127.0.0.1 -uroot < residents_bak.sql