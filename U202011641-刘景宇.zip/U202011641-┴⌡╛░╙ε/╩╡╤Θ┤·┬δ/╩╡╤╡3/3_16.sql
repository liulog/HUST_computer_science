-- 16) 查询持有相同基金组合的客户对，如编号为A的客户持有的基金，编号为B的客户也持有，反过来，编号为B的客户持有的基金，编号为A的客户也持有，则(A,B)即为持有相同基金组合的二元组，请列出这样的客户对。为避免过多的重复，如果(1,2)为满足条件的元组，则不必显示(2,1)，即只显示编号小者在前的那一对，这一组客户编号分别命名为c_id1,c_id2。

-- 请用一条SQL语句实现该查询：

SELECT
	c1.c_id as c_id1, c2.c_id as c_id2
FROM
	client c1 inner join client c2
WHERE
	c1.c_id < c2.c_id 
	AND EXISTS ( SELECT * FROM property WHERE pro_type = 3 AND pro_c_id = c1.c_id)
	AND EXISTS ( SELECT * FROM property WHERE pro_type = 3 AND pro_c_id = c2.c_id)
	AND NOT EXISTS (
	SELECT
		* 
	FROM
		( SELECT * FROM property WHERE pro_type = 3 AND pro_c_id = c1.c_id) AS ptb1
	WHERE NOT EXISTS (
		SELECT
			* 
		FROM
			 ( SELECT * FROM property WHERE pro_type = 3 AND pro_c_id = c2.c_id) AS ptb2
		WHERE
			ptb1.pro_pif_id = ptb2.pro_pif_id
		) 
	)
	AND NOT EXISTS (
	SELECT
		* 
	FROM
		 ( SELECT * FROM property WHERE pro_type = 3 AND pro_c_id = c2.c_id) AS ptb2
	WHERE NOT EXISTS (
		SELECT
			* 
		FROM
			( SELECT * FROM property WHERE pro_type = 3 AND pro_c_id = c1.c_id) AS ptb1
		WHERE
			ptb1.pro_pif_id = ptb2.pro_pif_id
		) 
	)
	;

	
/*  end  of  your code  */